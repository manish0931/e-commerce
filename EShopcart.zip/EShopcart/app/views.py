from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from django.views import View
from app.models import Customer, Product, Cart, OrderPlaced, Payment, CATEGORY_CHOICES  # Import Payment model
from app.forms import CustomerRegistrationForm, CustomerProfileForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
import json

# Existing view functions...

# New view to render the payment page
def payment_page(request):
    return render(request, 'payment.html')

# New view to process payment from the front-end
def process_payment(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        transaction_hash = data.get('transactionHash')
        amount = data.get('amount')

        # Save the payment information to the database
        payment = Payment.objects.create(
            transaction_hash=transaction_hash,
            amount_in_ether=amount
        )

        return JsonResponse({'status': 'success', 'message': 'Payment processed successfully', 'payment_id': payment.id})

    return JsonResponse({'status': 'error', 'message': 'Invalid request'}, status=400)

# Existing view functions...
